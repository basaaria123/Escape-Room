# The Last Experiment — showcase site
Static site (no build step). Deploy the folder as-is to Netlify, Vercel, GitHub Pages or any static host.
Preview locally: `python3 -m http.server 8000` then open http://localhost:8000

Game source: https://github.com/mehrajvalliya99-lang/Escape-Room-Game/tree/member2-gameplay
Compile: `javac -d bin src/*.java src/models/*.java src/screens/*.java`
Run: `java -cp bin Main`
