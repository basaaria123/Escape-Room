const $=s=>document.querySelector(s);
// dust motes
const dust=$('#dust');for(let i=0;i<28;i++){const d=document.createElement('i');d.style.left=Math.random()*100+'vw';d.style.top=(60+Math.random()*50)+'vh';d.style.animationDuration=(12+Math.random()*16)+'s';d.style.animationDelay=(-Math.random()*20)+'s';dust.appendChild(d)}
// flashlight
const hero=$('.hero'),dark=$('#dark');
const lamp=(x,y)=>{const r=hero.getBoundingClientRect();dark.style.setProperty('--x',x-r.left+'px');dark.style.setProperty('--y',y-r.top+'px')};
hero.addEventListener('mousemove',e=>lamp(e.clientX,e.clientY));
hero.addEventListener('touchmove',e=>lamp(e.touches[0].clientX,e.touches[0].clientY),{passive:true});
// countdown
let t=1200;const cd=$('#cd');
setInterval(()=>{t=t<=0?1200:t-1;cd.textContent=String(Math.floor(t/60)).padStart(2,'0')+':'+String(t%60).padStart(2,'0');cd.parentElement.classList.toggle('low',t<60)},1000);
// counters
const io=new IntersectionObserver(es=>es.forEach(e=>{if(!e.isIntersecting)return;io.unobserve(e.target);const n=+e.target.dataset.n;let i=0;const s=setInterval(()=>{e.target.textContent=++i;if(i>=n)clearInterval(s)},900/n)}),{threshold:.6});
document.querySelectorAll('[data-n]').forEach(b=>io.observe(b));
// data
const L=[
{t:"Level 1 · The Detective's Study",x:"Dr. Vance's office. Scattered research and locked furniture hold the first pieces. Your goal: find a way into the facility archive.",
 img:[['l1-study','Search the plant pot and you find a torn newspaper with a circled year.'],['l1-bookshelf','Hover any named object to see what you can inspect.'],['l1-newspaper','The Archive Chest asks for a four-digit date.']],
 s:[['Search the potted plant','Find a torn newspaper fragment with a circled date.'],['Inspect the desk lamp','Collect Dr. Vance\u2019s research note and a magnifying glass.'],['Open the archive chest','Enter the date from the newspaper to get the Library Access Key.',1]],
 o:['Desk drawer','Suspect\u2019s cipher note','Mantel clock','Scholar portrait plaque','Terrestrial coordinates (globe)']},
{t:"Level 2 · The Forgotten Library",x:"A high-security archive of manuscripts, records and schematics. It holds the credentials you need to reach the laboratory.",
 img:[['l2-library','High on shelf 8: a torn folder labeled EXPERIMENT and circuit schematics.'],['l2-clock','The grandfather clock is one of the optional puzzles.'],['l2-cabinet','The archive cabinet takes a four-digit catalog index.'],['l2-cipher','A Caesar cipher on the reading table manuscript.']],
 s:[['Search the library ladder','Find the EXPERIMENT folder with breaker schematics.'],['Examine the historical painting','Read the founding-team plaque for the cabinet index code.'],['Unlock the locked cabinet','Get the Lab Access Card and the Circuit Component.',1]],
 o:['Encrypted manuscript','Grandfather clock','Book arrangement','Secret shelf pattern']},
{t:"Level 3 · The Abandoned Laboratory",x:"The power grid is down and security is active. Restore power, recover the override code and take the vault key.",
 img:[['l3-lab','The lab hums with residual energy. Repair circuits and restore power.'],['inventory','Eight of nine inventory slots filled by this point.']],
 s:[['Inspect the power conduits','The three glowing teal conduits reveal a distribution sequence.'],['Restore facility power','Use the circuit breaker board with the Circuit Component.',1],['Inspect the research workstation','Experiment Report 103 reveals the lockdown override code.'],['Override the security lockdown','Enter the code at the security terminal to get the Ancient Vault Key.',1]],
 o:['Chemical reaction sequence','Resonance dial','Optical sensor grid']},
{t:"Level 4 · The Ancient Vault",x:"The relic is inside, but three safeguards remain. Complete them all, secure the artifact and open the exit portal.",
 img:[['l4-vault','The Ancient Vault contains the ultimate secrets of the experiment.'],['l3-relays','Containment relays: a symbol sequence puzzle.'],['l4-portal','The exit portal is sealed until all three objectives are done.']],
 s:[['Disengage the vault combination lock','The four tumbler rings release.',1],['Stabilize the containment relays','Put the symbols in the safe operating order.',1],['Align the ancient relic','Use the Ancient Vault Key at the artifact altar.',1],['Click the vault exit portal','The lockdown field drops and the victory screen appears.']],
 o:['Final decryption puzzle','Superconductor grid','Hydraulic release valves']}];
const tabs=$('#tabs');let cur=0,ci=0;
L.forEach((l,i)=>{const b=document.createElement('button');b.textContent='Level '+(i+1);b.setAttribute('role','tab');b.onclick=()=>show(i);tabs.appendChild(b)});
function pic(i){ci=i;const l=L[cur],im=$('#shotImg');im.src='assets/'+l.img[i][0]+'.jpg';im.alt=l.img[i][1];im.classList.remove('sw');void im.offsetWidth;im.classList.add('sw');$('#shotCap').textContent=l.img[i][1];[...$('#thumbs').children].forEach((c,k)=>c.classList.toggle('on',k===i))}
function show(i){cur=i;const l=L[i];[...tabs.children].forEach((b,k)=>b.classList.toggle('on',k===i));
$('#lvTitle').textContent=l.t;$('#lvText').textContent=l.x;
$('#steps').innerHTML=l.s.map(s=>`<li class="${s[2]?'req':''}"><strong>${s[0]}</strong>${s[2]?'<em>required</em>':''}<br><span>${s[1]}</span></li>`).join('');
$('#opts').innerHTML=l.o.map(o=>`<li>${o}</li>`).join('');
$('#thumbs').innerHTML='';l.img.forEach((m,k)=>{const t=document.createElement('img');t.src='assets/'+m[0]+'.jpg';t.alt='';t.onclick=()=>pic(k);$('#thumbs').appendChild(t)});pic(0)}
show(0);
// cipher
const word='DUWLIDFW',key='ARTIFACT',enc=$('#enc');
[...word].forEach(c=>{const s=document.createElement('span');s.textContent=c;enc.appendChild(s)});
let hs=0;const msg=$('#msg');
$('#hintB').onclick=()=>{hs++;msg.style.color='';msg.textContent=hs==1?'D moves back three letters to A. Count: D, C, B, A.':hs==2?'The first letters decode to A, R, T.':'The keyword starts with ART and ends with FACT.'};
function go(){const v=$('#ans').value.trim().toUpperCase();if(v===key){[...enc.children].forEach((s,i)=>setTimeout(()=>{s.textContent=key[i];s.classList.add('ok')},i*120));msg.style.color='var(--teal)';msg.textContent=`Correct. Cabinet open. ${hs?`Hints used: ${hs}.`:'No hints used.'}`}else{msg.style.color='#ff8b8b';msg.textContent='Not quite. Shift each letter back by three.';$('.cipher-box').classList.remove('shake');void $('.cipher-box').offsetWidth;$('.cipher-box').classList.add('shake')}}
$('#sub').onclick=go;$('#ans').onkeydown=e=>e.key==='Enter'&&go();
// case file
const A=[[1,'Archive chest','1947'],[1,'Desk drawer','425'],[1,'Suspect\u2019s cipher note','BOOKSHELF'],[1,'Mantel clock','425'],[1,'Scholar portrait','ARCHIMEDES'],[1,'Globe','GREENWICH'],[2,'Book arrangement','12345 or 1-2-3-4-5'],[2,'Encrypted manuscript','ARTIFACT'],[2,'High shelf manuscript','EXPERIMENT'],[2,'Archive security cabinet','4921'],[2,'Grandfather clock','11:45'],[2,'Secret shelf pattern','\u25A0, Hollow or Hollow Diamond'],[3,'Electrical circuit breakers','ALPHA BETA GAMMA DELTA'],[3,'Chemical reaction sequence','SOLVENT CATALYST REAGENT ISOTOPE'],[3,'Research workstation','EXP 103 or 103'],[3,'Security override terminal','8462'],[3,'Resonance dial','REACTOR'],[3,'Optical sensor grid','HEXAGON'],[4,'Vault combination lock','5284'],[4,'Containment relays','POWER COOLING VACUUM SHIELD'],[4,'Artifact altar alignment','RELIC CORE MATRIX ARTIFACT'],[4,'Final decryption puzzle','EXPERIMENT COMPLETE'],[4,'Superconductor grid','LABYRINTH'],[4,'Hydraulic release valves','SYNCHRONY']];
const tb=$('#tb');
function draw(f=''){tb.innerHTML=A.filter(r=>(r[0]+' '+r[1]).toLowerCase().includes(f.toLowerCase())).map(r=>`<tr><td>${r[0]}</td><td>${r[1]}</td><td><span class="red" tabindex="0" role="button">${r[2]}</span></td></tr>`).join('')}
draw();
tb.onclick=e=>e.target.classList.contains('red')&&e.target.classList.toggle('open');
tb.onkeydown=e=>{if((e.key==='Enter'||e.key===' ')&&e.target.classList.contains('red')){e.preventDefault();e.target.classList.toggle('open')}};
$('#q').oninput=e=>draw(e.target.value);
$('#all').onclick=()=>document.querySelectorAll('.red').forEach(r=>r.classList.add('open'));
// gallery + lightbox
const G=[['menu','Home screen'],['player','Player details and difficulty'],['l1-study','Level 1: the study'],['l1-bookshelf','Level 1: bookshelf'],['l1-newspaper','Torn newspaper puzzle'],['l2-library','Level 2: the library'],['l2-clock','Grandfather clock'],['l2-cipher','Caesar cipher'],['l2-cabinet','Archive cabinet solved'],['l3-lab','Level 3: the laboratory'],['inventory','Inventory'],['l3-relays','Containment relays puzzle'],['l4-vault','Level 4: the vault'],['l4-portal','The sealed exit portal'],['victory','You escaped']];
const lb=$('#lb');
G.forEach(g=>{const f=document.createElement('figure');f.innerHTML=`<img src="assets/${g[0]}.jpg" alt="${g[1]}" loading="lazy"><figcaption>${g[1]}</figcaption>`;f.onclick=()=>{lb.querySelector('img').src='assets/'+g[0]+'.jpg';lb.querySelector('p').textContent=g[1];lb.classList.add('on')};$('#grid').appendChild(f)});
$('.shot img').onclick=e=>{lb.querySelector('img').src=e.target.src;lb.querySelector('p').textContent=e.target.alt;lb.classList.add('on')};
lb.onclick=()=>lb.classList.remove('on');addEventListener('keydown',e=>e.key==='Escape'&&lb.classList.remove('on'));
// copy
document.querySelectorAll('[data-c]').forEach(b=>b.onclick=()=>{navigator.clipboard&&navigator.clipboard.writeText(b.dataset.c);b.textContent='Copied';setTimeout(()=>b.textContent='Copy',1400)});
// confetti on victory
const cv=$('#conf'),cx=cv.getContext('2d');let P=[],run=false;
function size(){cv.width=cv.offsetWidth;cv.height=cv.offsetHeight}size();addEventListener('resize',size);
function burst(){P=Array.from({length:120},()=>({x:Math.random()*cv.width,y:-Math.random()*cv.height*.6,w:4+Math.random()*5,h:8+Math.random()*6,v:1.5+Math.random()*3,r:Math.random()*6,s:(Math.random()-.5)*.2,c:['#f2c14e','#4fd1c5','#ff6b81','#9d7bff','#6ec6ff'][Math.floor(Math.random()*5)]}));if(!run){run=true;tick()}}
function tick(){cx.clearRect(0,0,cv.width,cv.height);P.forEach(p=>{p.y+=p.v;p.r+=p.s;cx.save();cx.translate(p.x,p.y);cx.rotate(p.r);cx.fillStyle=p.c;cx.fillRect(-p.w/2,-p.h/2,p.w,p.h);cx.restore()});P=P.filter(p=>p.y<cv.height+20);if(P.length)requestAnimationFrame(tick);else run=false}
new IntersectionObserver((es,o)=>es.forEach(e=>{if(e.isIntersecting&&!matchMedia('(prefers-reduced-motion:reduce)').matches)burst()}),{threshold:.5}).observe($('.victory'));
